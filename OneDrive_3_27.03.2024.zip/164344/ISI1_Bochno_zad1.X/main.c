/*
 * File:   main.c
 * Author: local
 *
 * Created on March 20, 2024, 12:03 PM
 */

// CONFIG2
#pragma config POSCMOD = HS             // Primary Oscillator Select (HS Oscillator mode selected)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = PRIPLL           // Oscillator Select (Primary Oscillator with PLL module (HSPLL, ECPLL))
#pragma config IESO = OFF               // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) disabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = ON              // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx2               // Comm Channel Select (Emulator/debugger uses EMUC2/EMUD2)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG port is disabled)

#include "xc.h"
#include <libpic30.h>

int main(void){
    unsigned int portValue = 0;
    AD1PCFG = 0xFFFF;
    TRISA = 0x0000;
    char currentS6 = 0, prevS6 = 0, currentS7 = 0, prevS7 = 0;
    while(1){
        prevS6 = PORTDbits.RD6;
        prevS7 = PORTDbits.RD7;
        currentS6 = PORTDbits.RD6;
        currentS7 = PORTDbits.RD7;
        if (currentS6 - prevS6 == 1){
            portValue++;
        }

        if (currentS7 - prevS7 == 1){
            portValue--;
        }
        prevS6 = currentS6;
        prevS7 = currentS7;
        switch(portValue){
            case 1:
                program1();
                break;
            case 2:
                program2();
                break;
            case 3:
                program3();
                break;
            case 4:
                program4();
                break;
        }
    }
    return 0;
}
void program1(){
    for(int i =0; i<255;i++){
        LATA = i;
        __delay32(1000000);
    }
    return;
}

void program2(){
    for(int i =254; i>0;i--){
        LATA = i;
        __delay32(1000000);
    }
}

int IntToGray(unsigned char input){
        return (input>>1)^input;
}

void program3(){
    for(int i =0; i<254;i++){
        LATA = IntToGray(i);
        __delay32(1000000);
    }
}

void program4(){
    for(int i =254; i>0;i--){
        LATA = IntToGray(i);
        __delay32(1000000);
    }
}

//int main(void) {
//    char currentS6 = 0, prevS6 = 0, currentS7 = 0, prevS7 = 0;
//    TRISA = 0x0000;
//    TRISD = 0xFFFF;
//    while (1){
//        LATA = portValue;
//        prevS6 = PORTDbits.RD6;
//        prevS7 = PORTDbits.RD7;
//        currentS6 = PORTDbits.RD6;
//        currentS7 = PORTDbits.RD7;
//        if (currentS6 - prevS6 == 1){
//            program1();
//        }
//
//        if (currentS7 - prevS7 == 1){
//            program2();
//        }
//        prevS6 = currentS6;
//        prevS7 = currentS7;
//        //__delay32(1000000);
//        //portValue++;
//    }
//    return 0;
//}
